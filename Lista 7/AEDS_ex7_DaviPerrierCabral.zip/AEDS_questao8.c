#include <stdio.h>

// falta terminar 8 | falar c henrique em sala sob duvida