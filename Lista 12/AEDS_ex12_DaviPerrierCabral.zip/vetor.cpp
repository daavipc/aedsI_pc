#include "vetor.h" 

Vetor::Vetor() { 
v = new int [TAMANHO];
 } 
int Vetor::obtemTamanho() { 
return 0; 
} 
void Vetor::insereNoFinal(int novoElemento) { } 
int Vetor::posicaoDe (int elemento) { return 0; } 
void Vetor::alteraEm (int pos, int novoValor) { } 
int Vetor::elementoDe (int pos) { return 0; } 
int Vetor::elementoEm (int pos) { return 0; } 
void Vetor::reverte() { }; 
void Vetor::imprime() { };