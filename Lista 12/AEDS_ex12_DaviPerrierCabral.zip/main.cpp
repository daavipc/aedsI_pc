/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <ctime>
#include "vetor.h"

using namespace std; 

int testaTamanhoVetor (Vetor *v){
    
    return v->obtemTamanho();
}

int main(int argc, char *argv[]){
    
    Vetor *v = new Vetor();
    
    v->insereNoFinal(10);
    v->insereNoFinal(8);
    v->insereNoFinal(16);
    v->insereNoFinal(7);
    v->insereNoFinal(5);
    v->insereNoFinal(13);
    v->insereNoFinal(14);
    v->insereNoFinal(15);
    v->insereNoFinal(17);
    v->insereNoFinal(19);

    
    v->imprime();
    
    int pos = v->posicaoDe(19);
    if(pos != -1)
        cout << "\nPosição: " << pos <<"\n";
    else 
        cout << "\nElemento não encontrado\n";
    
    v->alteraEm(0,99);
    v->alteraEm(3,19);
    v->alteraEm(9,99);

    v->imprime();
    
    cout << "\nTamanho do vetor: " <<v->obtemTamanho() << "\n";
    
    for(int i = 0; i < v->obtemTamanho(); i++)
        cout << "Elemento na posição " << i <<": " <<v->elementoEm(i) <<"\n";
       
    v->elementoEm(100);
    v->elementoEm(10);
        
    v->imprime();
    cout << "\n";
    v->reverte();
    v->imprime();
        
    
}