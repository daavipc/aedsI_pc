#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

int main(){  
for(i = p = 0; i < 5; i++){ 
printf("Digite um numero: ");    
scanf("%d", &vetor[i]);    
if(primo(vetor[i])){       
vp[p++] = vetor[i]; 
}   

for(i = 0; i < p; i++){  
printf("[%d]\n", vp[i]);    

} 
return 0;


}

}
