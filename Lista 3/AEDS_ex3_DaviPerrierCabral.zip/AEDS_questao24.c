#include<stdio.h>
#include<stdlib.h>

main(){
int num,num1=0,num2=0;
printf("Digite um conjunto de numero e 0 para encerrar \n");
scanf("%d",&num);
while (num!=0){
if(num<0) {
printf("Valor negativo, digite novamente %d\n",&num);
}
if(num>num1)
num1=num;
else if (num>=num2)
num2=num;
scanf("%d",&num);
}
printf("o maior valor é: %d \n",&num1);
printf("o menor valor é: %d \n",&num2);
}