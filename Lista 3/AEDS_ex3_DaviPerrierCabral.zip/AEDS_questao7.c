#include <stdio.h>

int main(){

int qnt_pessoas=5;

int idades[qnt_pessoas];  

float pesos[qnt_pessoas]; 
float alturas[qnt_pessoas]; 

float media_altura=0;

int idade50=0; 

int idade1020=0;

int pesos_total=0;

for(int cont=0;cont<qnt_pessoas;cont++){

printf("Digite a idade: ");

scanf("%i",&idades[cont]);  

printf("Digite o peso: ");

scanf("%i",&pesos[cont]);  

printf("Digite a altura: ");

scanf("%i",&alturas[cont]); 

printf("\n");

if(idades[cont] > 50)

idade50++;

if(idades[cont] >= 10 && idades[cont] <=20){

idade1020++;

media_altura += alturas[cont];

}

pesos_total += pesos[cont];

}

printf("Pessoas com mais de 50 anos: %i\n",idade50);

printf("Média de altura de pessoas entre 10 a 20 anos: %i\n",media_altura/idade1020);

printf("Média de pesos: %i\n",pesos_total/qnt_pessoas);

}

